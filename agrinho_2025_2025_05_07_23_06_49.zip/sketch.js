function setup() {
  createCanvas(600, 400);
  noLoop();
}

function draw() {
  background(135, 206, 250); // Céu azul

  // Campo (verde)
  fill(34, 139, 34);
  rect(0, 200, width / 2, 200);

  // Cidade (cinza)
  fill(169, 169, 169);
  rect(width / 2, 200, width / 2, 200);

  // Estrada conectando campo e cidade
  fill(50);
  rect(250, 200, 100, 200);
  
  // Linhas da estrada
  stroke(255, 255, 0);
  for (let i = 210; i < 400; i += 20) {
    line(295, i, 305, i + 10);
  }

  noStroke();
  
  // Árvore no campo
  fill(139, 69, 19);
  rect(100, 250, 20, 50);
  fill(34, 139, 34);
  ellipse(110, 230, 60, 60);

  // Plantação
  for (let x = 30; x < 200; x += 30) {
    fill(255, 223, 0);
    ellipse(x, 350, 20, 20);
  }

  // Prédios na cidade
  for (let x = 400; x < width; x += 50) {
    fill(random(100, 200));
    rect(x, random(220, 300), 40, 180);
  }
}
